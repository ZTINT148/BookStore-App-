import "./App.css";
import Navbar from "./Components/Navbar";
import Home from "./Components/Home";
import { Switch, Route, Routes } from "react-router-dom";
import Products from "./Components/Products";
import Product from "./Components/Product";
import Cart from "./Components/Cart";
import Contact from "./Components/Contact";
import About from "./Components/About";
import Footer1 from "./Components/Footer1";
import Login from "./Components/Login";
import Register from "./Components/Register";

function App() {
  return (
    <>
      <Navbar />
      <Routes>

        <Route  path="/" element={<Home/>} />
        <Route path="/products" element={<Products/>} />
        <Route path="/contact" element={<Contact/>} />
        <Route path="/products/:id" element={<Product/>} />
        <Route path="/about" element={<About/>} />
        <Route path="/cart" element={<Cart/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/register" element={<Register/>} />
        </Routes>

        <Footer1/>

    
    </>
  );
}

export default App;

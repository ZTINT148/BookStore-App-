import React from "react";

export default function About() {
  return (
    <>
      <div className="container mt-5">
        <div class="row featurette">
          <div class="col-md-7 my-auto">
            <h2 class="featurette-heading fw-normal lh-1">
              Books. <span class="text-muted">It’ll blow your mind.</span>
            </h2>
            <p class="lead">
              This site has an archive of more than one thousand seven hundred
              interviews, or eight thousand book recommendations. We publish at
              least two new interviews per week
            </p>
          </div>
          <div class="col-md-5">
            <img
              className='class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500"'
              src="images/book1.jpg"
              alt=""
            />
          </div>
        </div>
      </div>

      <hr class="featurette-divider"></hr>

      <div class="row featurette">
        <div class="col-md-7 order-md-2 my-auto">
          <h2 class="featurette-heading fw-normal lh-1">
            Oh yeah, it’s that good.{" "}
            <span class="text-muted">See for yourself.</span>
          </h2>
          <p class="lead">
            We ask experts to recommend the five best books in their subject and
            explain their selection in an interview
          </p>
        </div>
        <div class="col-md-5 order-md-1">
          <img
            src="images/book2.jpg"
            class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto"
            width="500"
            height="500"
            alt=""
          />
        </div>
      </div>
    </>
  );
}

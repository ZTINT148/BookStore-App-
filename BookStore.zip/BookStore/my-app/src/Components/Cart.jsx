import React from 'react';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { delCart } from '../redux/action/index';
import handleCart from '../redux/reducers/handleCart';
import Product from './Product';
import Products from './Products';


const Cart = () => {
    const state = useSelector((state)=> state.addCart)
    const dispatch = useDispatch()
    // const Cart = (Cart) =>{
        return (
            <div>
                <div className="row d-flex justify-content-center">
                    <div className="col-md-4">
                        
                        <img src="/images/cover.jpg" alt={Cart.title}  height = "300px"/>
                    </div>
                    <div className="col-md-4 my-auto">
                        <h3>{Cart.title}</h3>
                        <p className=' lead fw-bold'>
                            {Cart.qty} X $23.37 = $
                            {Cart.qty * 23.37}
                        </p>
                        <button className=' btn btn-outline-danger me-4' 
                        onClick={()=>handleCart(Cart)}> Place Order</button>
                        <button className=' btn btn-outline-danger me-4' 
                        onClick={()=>handleCart(Cart)}> Remove Order</button>
                    </div>
                </div>
    
            </div> 
        )
        
    }
    
// }

export default Cart ;



// import React from 'react'

// const Cart = () => {
//     const state = useSelector((state)=> state.addCart)
//     const dispatch = useDispatch()
//   return (
//     <div>
//     <div className="row">
//         <div className="col-md-4">
//             <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus consequatur possimus sed optio quidem repudiandae rerum? Consequatur laboriosam saepe dicta eveniet veritatis dolorum fugiat dolores odit labore doloribus fugit doloremque fuga facilis numquam natus iusto perferendis, adipisci repudiandae ipsa? Consequatur quia temporibus sequi non odio animi voluptatibus ducimus beatae autem.</p>
//             <img src={Cart.image} alt={Cart.title}  height = "200px"/>
//         </div>
//         <div className="col-md-4">
//             <h3>{Cart.title}</h3>
//             <p className=' lead fw-bold'>
//                 {Cart.qty} X $23.37 = $
//                 {Cart.qty * 23.37}
//             </p>
//             <button className=' btn btn-outline-danger me-4' 
//             onClick={()=>handleCart(Cart)}></button>
//             <button className=' btn btn-outline-danger me-4' 
//             onClick={()=>handleCart(Cart)}></button>
//         </div>
//     </div>

// </div> 
//   )
// }

// export default Cart ;

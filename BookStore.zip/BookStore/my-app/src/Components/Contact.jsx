import React from 'react';

export default function Contact() {
  return (
    <>
    <div>
        <div class="container bg-light">
        
        
        
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 form-wrapper" data-form-type="formoid">            
                <div class="form-head m-5">
                    <p class="mbr-section-subtitle form-subtitle  text-center">
                        CONTACT FORM
                    </p>
                    <h2 class=" text-center">
                        Get In Touch
                    </h2>
                </div>
                <div class="form1" data-form-type="formoid">
                    <div data-form-alert="" hidden="">Thanks for filling out the form!</div>
                    <form class="mbr-form"  method="post" data-form-title=""><input type="hidden" name="email" data-form-email="true" value=""/>
                        <div class="input-wrap" data-for="firstname">
                            <label class="form-label-outside mbr-lighter" for="form-1-firstname">Name</label>
                            <input type="text" class="form-control" name="firstname" data-form-field="First Name" required="" id="firstname-form4-1"/>
                        </div>

                        
                    
                        <div class="input-wrap" data-for="email">
                            <label class="form-label-outside mbr-lighter" for="form-1-email">Email</label>
                            <input type="email" class="form-control" name="email" data-form-field="Email" required="" id="email-form4-1"/>
                        </div>
                    
                        
                    
                        <div class="form-group" data-for="message">
                            <label class="form-label-outside mbr-lighter" for="form-1-message">Message</label>
                            <textarea type="text" class="form-control" name="message" rows="4" data-form-field="Message" id="message-form4-1"></textarea>
                        </div>
                    
                        <span class="input-group-btn "><button  type="submit" class="btn btn-lg btn-form btn-danger mt-2">Submit</button></span>
                    </form>
                </div>
            </div>
        </div>
   </div>
    </div>
    </>
  )
}

import React from 'react'
import Products from './Products'



export default function Home() {
  return (
    <>
    <div className="container-fluid">
    <div className="row" >
    <div className="col-sm-7">
             <img className='img-fluid' src="/images/cover.jpg" alt="" height="100px"/>       
        </div>
        <div className="col-sm-5 mt-5">
           <div className="display-1 fw-bolder het">12 <br /> RULES<br/> FOR LIFE</div>
            <div className="p1">
             <p className=' display-6'>One of the most important thinkers to encourage on the world stage for many years</p>
             <p className='text-danger'>THE SPACTATOR</p>
            </div>
        </div>
    </div> 
    <Products/>
    
    
    
</div>  
    </>
  )
}

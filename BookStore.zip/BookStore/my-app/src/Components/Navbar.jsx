import React from "react";
import { NavLink } from "react-router-dom";
import { useSelector } from "react-redux";
import Contact from "./Contact";

export default function Navbar() {
  const state = useSelector((state) => state.handleCart);
  return (
    <>
      <nav
        className="navbar navbar-expand-lg navbar-light"
        style={{ height: "100px" }}
      >
        <div className="container-fluid">
          <NavLink to="/">
            <img
              src="/images/logo.png"
              className="ms-5 img-fluid "
              style={{ height: "60px" }}
            />
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <nav className="stroke ">
              <ul className="navbar-nav  ">
                <li>
                  <NavLink to="">Home</NavLink>
                </li>
                <li>
                  <NavLink to="/products">Products</NavLink>
                </li>
                <li>
                  <NavLink to="/about">About Us</NavLink>
                </li>
                <li>
                  <NavLink to="/contact">Contact Us</NavLink>
                </li>
              </ul>
            </nav>
            <div className="buttons">
              <NavLink to="/login" className="btn btn-outline-danger ms-5  ">
                Login
              </NavLink>
              <NavLink to="/register" className="btn btn-outline-danger ms-3 ">
                Register
              </NavLink>
              <NavLink to="/cart" className="btn btn-outline-danger ms-3 me-5 ">
                Cart ({state.length})
              </NavLink>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
}

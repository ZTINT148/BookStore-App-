import React, {useState, useEffect} from 'react';
import { useDispatch } from 'react-redux';
import { addCart } from '../redux/action';
import { useParams } from 'react-router';
import { NavLink } from 'react-router-dom';


const Product = () => {

  const id = []
  const [data, setData] = useState([])
//   const [filter, setFilter] = useState([]);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const addProduct = (product) => {
    dispatch(addCart(product));
  }

  let componentMounted = true;


  useEffect(() => {
    const getProducts = async () => {
      const response = await fetch(`https://www.dbooks.org/api/recent`);

      if (componentMounted) {
        const data = await response.json()
        setData(data.books)
        // setFilter(await response.json());
        setLoading(false);
        // console.log(filter);
      }
      return () => {
        componentMounted = false;
      };
     
    }
    getProducts()
  }, []);






    // const {id} = useParams();
    // const [product, setProduct] = useState([]);
    // const [loading, setLoading] = useState(false); 

    // useEffect(() => {
    //     const getProduct = async()=>{
    //         setLoading(true);
    //         const response = await fetch (` https://www.dbooks.org/api/book/{id}
    //         `);
    //         setProduct(await response.json());
    //         setLoading(false);
            

    //     }

    //     getProduct();
     
    
      
    // }, [])

    const Loading = ()=>{
        return(
            <>
            Loading...
            </>
        )
    }
    const ShowProduct = ()=>{
        return(

            



            <>

{data.map((product) => {
            
            return (
              <>
                <div className="col-md-6 mt-5">
                <img src={product.image} alt={product.title} height ="400px" />
            </div>
            <div className="col-md-6 mt-5 py-5">
                
                <h1 className='display-5'> {product.title}</h1>
                <h4 className='lead'>
                    {product.subtitle}
                </h4>
                <h6>Authore : {product.authors}</h6>
                <h3> $22.37</h3>
                <button  className='btn btn-outline-danger mt-3' onClick={()=>addProduct(product)}>Add to Cart</button> 
                <NavLink to="/cart" className='btn btn-danger ms-4 mt-3'>Go to Cart</NavLink>

            </div>
              </>
            );
          })}






            
            </>
        )
    }
    
    

  return (
    <div>
        <div className="container">
            <div className="row px-5">
                {loading ? <Loading/> : <ShowProduct/>}
            </div>
        </div>
    </div>
  )
}
 
export default Product ;


// import React from 'react'

// export default function Product() {
//   return (
//     <div>{books.image}</div>
//   )
// }





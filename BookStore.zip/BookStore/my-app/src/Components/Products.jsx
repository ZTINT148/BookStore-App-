import React, { useState, useEffect } from "react";
import Skeleton from "react-loading-skeleton";
import { NavLink } from "react-router-dom";





const Products = () => {


  const [data, setData] = useState([])
  const [filter, setFilter] = useState([]);
  const [loading, setLoading] = useState(false);

  let componentMounted = true;


  useEffect(() => {
    const getProducts = async () => {
      // setLoading(true);
      const response = await fetch("https://www.dbooks.org/api/recent");

      if (componentMounted) {
        const data = await response.json()
        setData(data.books)
        setFilter(await response.json());
        setLoading(false);
        console.log(filter);
      }
      return () => {
        componentMounted = false;
      };
     
    }
    getProducts()
  }, []);



  // const [data, setData] = useState([]);
  // const [filter, setFilter] = useState(data);
  // const [loading, setLoading] = useState(false);

  // let componentMounted = true;

  // useEffect(() => {
  //   const getProducts = async () => {
  //     setLoading(true);
  //     const response = await fetch(`https://www.dbooks.org/api/recent`);
  //     if (componentMounted) {
  //       setData(data.books)
  //       setData(await response.clone().json());
  //       setFilter(await response.json());
  //       setLoading(false);
  //       console.log(filter);
  //     }
  //     return () => {
  //       componentMounted = false;
  //     };
  //   };
  //   getProducts();
  // }, []);

  const Loading = () => {
    return ( 
    <>
    <div className="col-md-3">
        <Skeleton height={350}/>
    </div>
    <div className="col-md-3">
        <Skeleton height={350}/>
    </div>
    <div className="col-md-3">
        <Skeleton height={350}/>
    </div>
    <div className="col-md-3">
        <Skeleton height={350}/>
    </div>
    </>
    );
  };

  const filterProduct = (cat) => {
    const updatedList = data.filter((x)=>x.category === cat);
    setFilter(updatedList);
  }

  const ShowProducts = () => {
    return (
      <>
        <div className="container-fluid mt-5">
          <section id="minimal-statistics">
            <div className="row">
              <div className="col-xl-3 col-sm-6 col-12">
                <div className="card">
                  <div className="card-content">
                    <div className="card-body">
                      <div className="media d-flex">
                        <div className="media-body text-right">
                          <h3>
                            <button className="btn btn-outline-warning" onClick={()=>setFilter(data)}>All</button>
                            <i className="bi bi-image orange600 ms-5"></i>
                          </h3>
                          <span>New Posts</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-sm-6 col-12">
                <div className="card">
                  <div className="card-content">
                    <div className="card-body">
                      <div className="media d-flex">
                        <div className="media-body text-right">
                          <h3>
                            <button className="btn btn-outline-primary" onClick={()=>filterProduct("men's clothing")}>Biography</button>
                            <i className="bi bi-person-badge blue600 ms-5"></i>
                          </h3>
                          <span>New Comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-sm-6 col-12">
                <div className="card">
                  <div className="card-content">
                    <div className="card-body">
                      <div className="media d-flex">
                        <div className="media-body text-right">
                          <h3>
                            <button className="btn btn-outline-danger" onClick={()=>filterProduct("women's clothing")}>Romance</button>
                            <span className="bi bi-balloon-heart red600 ms-5"></span>
                          </h3>
                          <span>Bounce Rate</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-sm-6 col-12">
                <div className="card">
                  <div className="card-content">
                    <div className="card-body">
                      <div className="media d-flex">
                        <div className="media-body text-right">
                          <h3>
                            <button className="btn btn-outline-success" onClick={()=>filterProduct("jewelery")}>Health</button>
                            <i className="bi bi-clipboard-pulse green600 ms-5"></i>
                          </h3>
                          <span>Total Visits</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
    
        {data.map((product) => {
            
          return (
            <>
              <div className="col-md-3 mt-5">
                <div className="card h-100 text-center p-4" key={product.id} >
                  <img src={product.image} className="card-img-top" alt={product.title} height = "250px"  />
                  <div className="card-body">
                    <h5 className="card-title mb-0">{product.title.substring(0,12)}</h5>
                    <p className="card-text">
                      $23.47
                    </p>
                    <NavLink to={`/products/${product.id}`} className="btn btn-danger">
                      Buy Now
                    </NavLink>
                  </div>
                </div>
              </div>
            </>
          );
        })}
      </>
    );
  };

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12">
            <h1 className="mt-5 text-center">Latest Books</h1>
          </div>
        </div>
        <div className="row justify-content-center">
          {loading ? <Loading /> : <ShowProducts />}
        </div>
      </div>
    </>
  );
};
export default Products;
